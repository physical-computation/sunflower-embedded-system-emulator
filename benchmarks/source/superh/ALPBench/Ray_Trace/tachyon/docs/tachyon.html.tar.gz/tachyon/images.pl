# LaTeX2HTML 99.2beta6 (1.42)
# Associate images original text with physical files.


$key = q/#;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.gif"
 ALT="$\char93 $">|; 

$key = q/###;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.gif"
 ALT="$\char93 \char93 \char93 $">|; 

$key = q/{displaymath}frac{1}{K_c+K_ld+k_qd^2}{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="47" BORDER="0"
 SRC="|."$dir".q|img3.gif"
 ALT="\begin{displaymath}
\frac {1} {K_c + K_l d + k_q d^2}
\end{displaymath}">|; 

1;

