# LaTeX2HTML 99.2beta6 (1.42)
# Associate internals original text with physical files.


$key = q/eq:attenuation/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/index:label/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

1;

